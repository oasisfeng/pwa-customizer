import {
  CONFIGURATIONS_KEY,
  SCHEMA_VERSION,
  SCHEMA_VERSION_KEY,
  activeTabColorOverrideCss,
  configurationForUrl,
  createConfiguration,
  newTabUrlForManifest,
  permissionOrigins,
  validateConfiguration,
} from "./lib/config.js";

const MANIFEST_CONTENT_SCRIPT_ID = "better-pwas-managed";
const CLOSE_TAB_CONTENT_SCRIPT_ID = "better-pwas-close-tab";
const ENABLED_ICON = "images/icon48.png";
const DISABLED_ICON = "images/iconDisabled48.png";
const ENABLED_TEXT = "Better PWAs: replacement manifest active";
const DISABLED_TEXT = "Better PWAs: no active configuration";
const TAB_SNAPSHOT_PREFIX = "better-pwas-tab:";
const CLOSED_TABS_PREFIX = "better-pwas-closed-tabs:";
const MAX_CLOSED_TABS_PER_WINDOW = 25;

let reconciliation = Promise.resolve();
let tabHistoryMutation = Promise.resolve();

chrome.runtime.onInstalled.addListener(() => {
  queueReconciliation()
    .then(reloadExistingTabbedPwaTabs)
    .catch((error) => console.error(error));
});
chrome.runtime.onStartup.addListener(() => queueReconciliation());
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[CONFIGURATIONS_KEY]) queueReconciliation();
});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.tabs.onCreated.addListener((tab) => {
  saveTabSnapshot(tab).catch(() => {});
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs
    .get(tabId)
    .then((tab) => Promise.all([saveTabSnapshot(tab), updateActionForTab(tab)]))
    .catch(() => {});
});
chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  saveTabSnapshot(tab).catch(() => {});
  if (changeInfo.url || changeInfo.status === "complete") {
    updateActionForTab(tab).catch(() => {});
  }
});
chrome.tabs.onMoved.addListener((tabId, moveInfo) => {
  updateTabSnapshotPosition(tabId, moveInfo.windowId, moveInfo.toIndex).catch(() => {});
});
chrome.tabs.onAttached.addListener((tabId, attachInfo) => {
  updateTabSnapshotPosition(tabId, attachInfo.newWindowId, attachInfo.newPosition).catch(() => {});
});
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  queueTabHistoryMutation(() => recordRemovedTab(tabId, removeInfo)).catch(() => {});
});
chrome.windows.onRemoved.addListener((windowId) => {
  chrome.storage.session.remove(closedTabsKey(windowId)).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(sendResponse).catch((error) => {
    sendResponse({ ok: false, error: error.message });
  });
  return true;
});

queueReconciliation();
seedTabSnapshots().catch(() => {});

async function handleMessage(message, sender) {
  switch (message?.type) {
    case "getState":
      assertManagementSender(sender);
      return {
        ok: true,
        templates: await loadTemplates(),
        configurations: await getConfigurations(),
      };
    case "saveConfiguration":
      assertManagementSender(sender);
      return saveConfiguration(message.configuration);
    case "deleteConfiguration":
      assertManagementSender(sender);
      return deleteConfiguration(message.id);
    case "replaceConfigurations":
      assertManagementSender(sender);
      return replaceConfigurations(message.configurations);
    case "getConfigurationForPage":
      if (!sender.tab?.url) return { ok: false, error: "Page URL is unavailable." };
      return getConfigurationForPage(sender.tab.url, sender.tab.id);
    case "openNewTab":
      return openNewTab(sender);
    case "reopenClosedTab":
      return reopenClosedTab(sender);
    case "closeCurrentTab":
      return closeCurrentTab(sender);
    case "manifestInjected":
      if (sender.tab?.id && sender.tab.url) {
        const configuration = configurationForUrl(await getConfigurations(), sender.tab.url);
        if (configuration?.id === message.configurationId) {
          await setAction(ENABLED_ICON, ENABLED_TEXT, sender.tab.id);
        }
      }
      return { ok: true };
    default:
      return { ok: false, error: "Unknown request." };
  }
}

function assertManagementSender(sender) {
  if (!sender.url?.startsWith(chrome.runtime.getURL(""))) {
    throw new Error("This request is only available from the settings page.");
  }
}

async function loadTemplates() {
  const catalog = await fetch(chrome.runtime.getURL("templates/catalog.json")).then((response) => {
    if (!response.ok) throw new Error("Could not load the template catalog.");
    return response.json();
  });

  return Promise.all(
    catalog.templates.map(async (template) => ({
      ...template,
      replaceExistingManifest: template.replaceExistingManifest !== false,
      rules: template.rules ?? [],
      manifest: await fetch(chrome.runtime.getURL(template.manifestPath)).then((response) => {
        if (!response.ok) throw new Error(`Could not load ${template.manifestPath}.`);
        return response.json();
      }),
    })),
  );
}

async function getConfigurations() {
  const stored = await chrome.storage.local.get([CONFIGURATIONS_KEY, SCHEMA_VERSION_KEY]);
  if (Array.isArray(stored[CONFIGURATIONS_KEY])) {
    if (stored[SCHEMA_VERSION_KEY] !== SCHEMA_VERSION) {
      await chrome.storage.local.set({ [SCHEMA_VERSION_KEY]: SCHEMA_VERSION });
    }
    return stored[CONFIGURATIONS_KEY];
  }

  const templates = await loadTemplates();
  const configurations = templates
    .filter((template) => template.enabledByDefault)
    .map((template) => createConfiguration(template, `default-${template.id}`));
  await chrome.storage.local.set({
    [CONFIGURATIONS_KEY]: configurations,
    [SCHEMA_VERSION_KEY]: SCHEMA_VERSION,
  });
  return configurations;
}

async function saveConfiguration(configuration) {
  const errors = validateConfiguration(configuration);
  if (errors.length) return { ok: false, error: errors.join(" ") };

  const configurations = await getConfigurations();
  const index = configurations.findIndex((item) => item.id === configuration.id);
  const value = {
    ...structuredClone(configuration),
    id: configuration.id || crypto.randomUUID(),
    templateId: configuration.templateId ?? null,
    createdAt: configuration.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  if (index === -1) configurations.push(value);
  else configurations[index] = value;
  await chrome.storage.local.set({ [CONFIGURATIONS_KEY]: configurations });
  return { ok: true, configuration: value };
}

async function deleteConfiguration(id) {
  const configurations = (await getConfigurations()).filter((item) => item.id !== id);
  await chrome.storage.local.set({ [CONFIGURATIONS_KEY]: configurations });
  return { ok: true };
}

async function replaceConfigurations(configurations) {
  if (!Array.isArray(configurations)) return { ok: false, error: "Import must contain an array." };
  const errors = configurations.flatMap((configuration, index) =>
    validateConfiguration(configuration).map((error) => `Configuration ${index + 1}: ${error}`),
  );
  if (errors.length) return { ok: false, error: errors.join(" ") };

  const imported = configurations.map((configuration) => ({
    ...structuredClone(configuration),
    id: configuration.id || crypto.randomUUID(),
    enabled: false,
    createdAt: configuration.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }));
  await chrome.storage.local.set({ [CONFIGURATIONS_KEY]: imported });
  return { ok: true };
}

function tabSnapshotKey(tabId) {
  return `${TAB_SNAPSHOT_PREFIX}${tabId}`;
}

function closedTabsKey(windowId) {
  return `${CLOSED_TABS_PREFIX}${windowId}`;
}

function queueTabHistoryMutation(task) {
  const result = tabHistoryMutation.then(task);
  tabHistoryMutation = result.catch((error) => console.error(error));
  return result;
}

async function seedTabSnapshots() {
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map((tab) => saveTabSnapshot(tab)));
}

async function saveTabSnapshot(tab) {
  const url = tab?.url ?? tab?.pendingUrl;
  if (tab?.id == null || tab.windowId == null || !url) return;

  await chrome.storage.session.set({
    [tabSnapshotKey(tab.id)]: {
      windowId: tab.windowId,
      index: tab.index,
      url,
    },
  });
}

async function updateTabSnapshotPosition(tabId, windowId, index) {
  const key = tabSnapshotKey(tabId);
  const stored = await chrome.storage.session.get(key);
  const snapshot = stored[key];
  if (!snapshot) {
    const tab = await chrome.tabs.get(tabId);
    await saveTabSnapshot(tab);
    return;
  }

  await chrome.storage.session.set({
    [key]: {
      ...snapshot,
      windowId,
      index,
    },
  });
}

async function recordRemovedTab(tabId, removeInfo) {
  const key = tabSnapshotKey(tabId);
  const stored = await chrome.storage.session.get(key);
  const snapshot = stored[key];
  await chrome.storage.session.remove(key);

  if (removeInfo.isWindowClosing || !snapshot || snapshot.windowId !== removeInfo.windowId) return;

  const stackKey = closedTabsKey(removeInfo.windowId);
  const stackState = await chrome.storage.session.get(stackKey);
  const stack = Array.isArray(stackState[stackKey]) ? stackState[stackKey] : [];
  stack.unshift(snapshot);
  await chrome.storage.session.set({
    [stackKey]: stack.slice(0, MAX_CLOSED_TABS_PER_WINDOW),
  });
}

async function reopenClosedTab(sender) {
  const tab = sender.tab;
  if (tab?.windowId == null) {
    return { ok: false, error: "Current PWA window is unavailable." };
  }

  return queueTabHistoryMutation(async () => {
    const stackKey = closedTabsKey(tab.windowId);
    const stackState = await chrome.storage.session.get(stackKey);
    const stack = Array.isArray(stackState[stackKey]) ? stackState[stackKey] : [];
    const closedTab = stack[0];
    if (!closedTab?.url) return { ok: true, reopened: false };

    const openTabs = await chrome.tabs.query({ windowId: tab.windowId });
    const index = Number.isInteger(closedTab.index)
      ? Math.min(Math.max(closedTab.index, 0), openTabs.length)
      : openTabs.length;

    await chrome.tabs.create({
      windowId: tab.windowId,
      index,
      url: closedTab.url,
      active: true,
    });

    const remaining = stack.slice(1);
    if (remaining.length) {
      await chrome.storage.session.set({ [stackKey]: remaining });
    } else {
      await chrome.storage.session.remove(stackKey);
    }
    return { ok: true, reopened: true };
  });
}

async function openNewTab(sender) {
  const tab = sender.tab;
  if (!tab?.url || tab.windowId == null) {
    return { ok: false, error: "Current PWA tab is unavailable." };
  }

  const configuration = configurationForUrl(await getConfigurations(), tab.url);
  if (!configuration) return { ok: false, error: "No active PWA configuration matches this tab." };

  // Match Chromium's tabbed-PWA semantics: tab_strip.new_tab_button.url wins,
  // otherwise the app's start_url is used.
  const url = newTabUrlForManifest(configuration.manifest, tab.url);
  if (!url) return { ok: false, error: "The PWA new-tab URL is invalid." };

  await chrome.tabs.create({
    windowId: tab.windowId,
    url,
    active: true,
  });
  return { ok: true };
}

async function closeCurrentTab(sender) {
  if (!sender.tab?.id) return { ok: false, error: "Current tab is unavailable." };
  await saveTabSnapshot(sender.tab);
  await chrome.tabs.remove(sender.tab.id);
  return { ok: true };
}

async function getConfigurationForPage(url, tabId) {
  const configuration = configurationForUrl(await getConfigurations(), url);
  if (!configuration) return { ok: true, configuration: null };
  const overrideCss = activeTabColorOverrideCss(configuration);
  if (overrideCss) {
    await chrome.scripting.insertCSS({
      target: { tabId },
      css: overrideCss,
      origin: "USER",
    });
  }
  const manifest = resolveManifestUrls(configuration.manifest, url);
  await inlineExtensionImages(manifest);
  return {
    ok: true,
    configuration: {
      id: configuration.id,
      replaceExistingManifest: configuration.replaceExistingManifest,
      manifest,
    },
  };
}

function resolveManifestUrls(manifest, pageUrl) {
  const resolved = structuredClone(manifest);
  const pageOrigin = new URL("/", pageUrl);
  const resolve = (value) => {
    if (typeof value !== "string" || /^(data:|blob:|https?:|chrome-extension:)/.test(value)) {
      return value;
    }
    if (value.startsWith("icons/")) return chrome.runtime.getURL(`manifests/${value}`);
    return new URL(value, pageOrigin).href;
  };
  const visit = (value) => {
    if (Array.isArray(value)) return value.forEach(visit);
    if (!value || typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      if (["src", "url", "action"].includes(key)) value[key] = resolve(child);
      else visit(child);
    }
  };
  if (resolved.start_url) resolved.start_url = resolve(resolved.start_url);
  if (resolved.scope) resolved.scope = resolve(resolved.scope);
  if (resolved.id && !/^[a-z][a-z\d+.-]*:/i.test(resolved.id)) resolved.id = resolve(resolved.id);
  visit(resolved);
  return resolved;
}

async function inlineExtensionImages(value) {
  if (Array.isArray(value)) {
    await Promise.all(value.map(inlineExtensionImages));
    return;
  }
  if (!value || typeof value !== "object") return;

  if (typeof value.src === "string" && value.src.startsWith(chrome.runtime.getURL(""))) {
    const response = await fetch(value.src);
    if (!response.ok) throw new Error(`Could not load bundled image: ${value.src}`);
    const blob = await response.blob();
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 32768) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
    }
    value.src = `data:${blob.type};base64,${btoa(binary)}`;
  }
  await Promise.all(Object.values(value).map(inlineExtensionImages));
}

function queueReconciliation() {
  reconciliation = reconciliation.then(reconcile).catch((error) => console.error(error));
  return reconciliation;
}

async function reconcile() {
  const configurations = await getConfigurations();
  const enabled = [];
  for (const configuration of configurations.filter((item) => item.enabled)) {
    if (await chrome.permissions.contains({ origins: permissionOrigins(configuration.matchPatterns) })) {
      enabled.push(configuration);
    }
  }

  const contentScriptIds = [MANIFEST_CONTENT_SCRIPT_ID, CLOSE_TAB_CONTENT_SCRIPT_ID];
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: contentScriptIds });
  if (existing.length) {
    await chrome.scripting.unregisterContentScripts({ ids: existing.map((script) => script.id) });
  }
  const matches = [...new Set(enabled.flatMap((configuration) => configuration.matchPatterns))];
  if (matches.length) {
    await chrome.scripting.registerContentScripts([
      {
        id: MANIFEST_CONTENT_SCRIPT_ID,
        js: ["injectManifest.js"],
        matches,
        persistAcrossSessions: true,
        runAt: "document_start",
      },
      {
        id: CLOSE_TAB_CONTENT_SCRIPT_ID,
        js: ["closeTabShortcut.js"],
        matches,
        allFrames: true,
        persistAcrossSessions: true,
        runAt: "document_start",
      },
    ]);
  }

  const oldRules = await chrome.declarativeNetRequest.getDynamicRules();
  const rules = enabled.flatMap((configuration) =>
    configuration.rules
      .filter((rule) => rule.enabled !== false)
      .map((rule) => {
        const { name: _name, enabled: _enabled, id: _id, ...declarativeRule } = rule;
        return declarativeRule;
      }),
  );
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldRules.map((rule) => rule.id),
    addRules: rules.map((rule, index) => ({ ...rule, id: index + 1 })),
  });
}

async function reloadExistingTabbedPwaTabs() {
  const configurations = await getConfigurations();
  const tabs = await chrome.tabs.query({});

  await Promise.all(
    tabs.map(async (tab) => {
      if (!tab.id || !tab.url) return;
      const configuration = configurationForUrl(configurations, tab.url);
      if (!configuration) return;
      const hasAccess = await chrome.permissions.contains({
        origins: permissionOrigins(configuration.matchPatterns),
      });
      if (!hasAccess) return;

      try {
        const [{ result: isTabbedPwa } = {}] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => matchMedia("(display-mode: tabbed)").matches,
        });
        if (isTabbedPwa) await chrome.tabs.reload(tab.id);
      } catch {
        // The tab can disappear while extension installation/update is settling.
      }
    }),
  );
}

async function updateActionForTab(tab) {
  if (!tab?.id || !tab.url) return;
  const configuration = configurationForUrl(await getConfigurations(), tab.url);
  const hasAccess =
    configuration &&
    (await chrome.permissions.contains({ origins: permissionOrigins(configuration.matchPatterns) }));
  await setAction(
    hasAccess ? ENABLED_ICON : DISABLED_ICON,
    hasAccess ? `Better PWAs: ${configuration.name} configured` : DISABLED_TEXT,
    tab.id,
  );
}

function setAction(icon, title, tabId) {
  return Promise.all([
    chrome.action.setIcon({ path: { 48: icon }, tabId }),
    chrome.action.setTitle({ title, tabId }),
  ]);
}
